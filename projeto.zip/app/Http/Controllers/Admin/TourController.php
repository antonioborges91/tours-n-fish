<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreTourRequest;
use App\Http\Requests\UpdateTourRequest;
use App\Models\Tour;
use App\Models\TourImage;
use App\Models\TourOption;
use App\Models\TourOptionSchedule;
use App\Models\TourOptionTranslation;
use App\Models\TourSchedule;
use App\Models\TourTranslation;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class TourController extends Controller
{
    public function index()
    {
        $tours = Tour::with('translations')
            ->orderBy('display_order')
            ->get();

        return view('admin.tours.index', compact('tours'));
    }

    public function create()
    {
        return view('admin.tours.create');
    }

    public function edit(Tour $tour)
    {
        $tour->load([
            'translations',
            'schedules',
            'images',
        ]);

        return view('admin.tours.edit', compact('tour'));
    }

    public function update(UpdateTourRequest $request, Tour $tour)
    {
        $data = $request->validated();
         // Atualizar imagem de capa
        if ($request->hasFile('cover_image')) {

            // Apagar imagem antiga
            if ($tour->cover_image && Storage::disk('public')->exists($tour->cover_image)) {
                Storage::disk('public')->delete($tour->cover_image);
            }

            // Guardar nova imagem
            $tour->cover_image = $request
                ->file('cover_image')
                ->store('tours/covers', 'public');

}

        // Atualizar passeio
        $tour->pricing_model = $data['pricing_model'];
        $tour->price = $data['price'];
        $tour->duration = $data['duration'];
        $tour->max_capacity = $data['max_capacity'];
        $tour->featured_home = $request->boolean('featured_home');
        $tour->available = $request->boolean('available');

        $tour->save();

        // Atualizar tradução Português
        $tour->translations()
            ->where('locale', 'pt')
            ->update([
                'name'                  => $data['pt_name'],
                'short_description'     => $data['pt_short_description'],
                'full_description'      => $data['pt_description'],
                'important_information' => $data['pt_information'],
            ]);

        // Atualizar tradução Inglês
        $tour->translations()
            ->where('locale', 'en')
            ->update([
                'name'                  => $data['en_name'],
                'short_description'     => $data['en_short_description'],
                'full_description'      => $data['en_description'],
                'important_information' => $data['en_information'],
            ]);
        // Atualizar horários
        // Apagar todos os horários existentes
        $tour->schedules()->delete();

        // Criar novamente os horários enviados
        if (!empty($data['schedule_start'])) {

            foreach ($data['schedule_start'] as $index => $startTime) {

                if (
                    empty($startTime) ||
                    empty($data['schedule_end'][$index])
                ) {
                    continue;
                }

                TourSchedule::create([
                    'tour_id'       => $tour->id,
                    'start_time'    => $startTime,
                    'end_time'      => $data['schedule_end'][$index],
                    'display_order' => $index,
                ]);
            }
        }
       // Substituir imagens existentes
        if ($request->hasFile('gallery_replace')) {

            foreach ($request->file('gallery_replace') as $imageId => $newImage) {

                if (!$newImage) {
                    continue;
                }

                $galleryImage = $tour->images()->find($imageId);

                if (!$galleryImage) {
                    continue;
                }

                // Apagar imagem antiga
                if (
                    $galleryImage->image &&
                    Storage::disk('public')->exists($galleryImage->image)
                ) {
                    Storage::disk('public')->delete($galleryImage->image);
                }

                // Guardar nova imagem
                $imagePath = $newImage->store('tours/gallery', 'public');

                // Atualizar registo
                $galleryImage->update([
                    'image' => $imagePath,
                ]);
            }
        }

        // Adicionar novas imagens à galeria
        if ($request->hasFile('gallery_images')) {

            $displayOrder = $tour->images()->count();

            foreach ($request->file('gallery_images') as $image) {

                if (!$image) {
                    continue;
                }

                $imagePath = $image->store('tours/gallery', 'public');

                TourImage::create([
                    'tour_id' => $tour->id,
                    'image' => $imagePath,
                    'display_order' => $displayOrder++,
                ]);
            }
        }
        return redirect()
            ->route('admin.tours.index')
            ->with('success', 'Passeio atualizado com sucesso.');
    }

    public function store(StoreTourRequest $request)
    {
        $data = $request->validated();

        // Upload da imagem de capa (FORA da transação)
        $coverImage = null;
        if ($request->hasFile('cover_image')) {
            $coverImage = $request
                ->file('cover_image')
                ->store('tours/covers', 'public');
        }

        // Upload das imagens de galeria (FORA da transação)
        $galleryImagePaths = [];
        if ($request->hasFile('gallery_images')) {
            foreach ($request->file('gallery_images') as $image) {
                if ($image) {
                    $galleryImagePaths[] = $image->store('tours/gallery', 'public');
                }
            }
        }

        // Valores booleanos extraídos antes da transação
        $featuredHome = $request->boolean('featured_home');
        $available = $request->boolean('available');

        // Operações de base de dados dentro da transação
        DB::transaction(function () use ($data, $coverImage, $galleryImagePaths, $featuredHome, $available) {
            // Criar passeio
            $tour = Tour::create([
                'cover_image'   => $coverImage,
                'max_capacity'  => $data['max_capacity'],
                'featured_home' => $featuredHome,
                'available'     => $available,
                'display_order' => 0,
            ]);

            // Tradução Português
            TourTranslation::create([
                'tour_id'               => $tour->id,
                'locale'                => 'pt',
                'name'                  => $data['pt_name'],
                'short_description'     => $data['pt_short_description'],
                'full_description'      => $data['pt_description'],
                'important_information' => $data['pt_information'],
            ]);

            // Tradução Inglês
            TourTranslation::create([
                'tour_id'               => $tour->id,
                'locale'                => 'en',
                'name'                  => $data['en_name'],
                'short_description'     => $data['en_short_description'],
                'full_description'      => $data['en_description'],
                'important_information' => $data['en_information'],
            ]);

            // Criar opções com suas traduções e horários
            foreach ($data['options'] as $optionIndex => $optionData) {
                // Criar opção
                $option = TourOption::create([
                    'tour_id'          => $tour->id,
                    'duration_minutes' => $optionData['duration_minutes'],
                    'price'            => $optionData['price'],
                    'display_order'    => $optionIndex,
                ]);

                // Criar traduções da opção
                TourOptionTranslation::create([
                    'tour_option_id' => $option->id,
                    'locale'         => 'pt',
                    'name'           => $optionData['translations']['pt']['name'],
                ]);

                TourOptionTranslation::create([
                    'tour_option_id' => $option->id,
                    'locale'         => 'en',
                    'name'           => $optionData['translations']['en']['name'],
                ]);

                // Criar horários da opção
                foreach ($optionData['schedules'] as $scheduleIndex => $scheduleData) {
                    TourOptionSchedule::create([
                        'tour_option_id' => $option->id,
                        'start_time'     => $scheduleData['start_time'],
                        'end_time'       => $scheduleData['end_time'],
                        'display_order'  => $scheduleIndex,
                    ]);
                }
            }

            // Criar registos de imagens da galeria
            foreach ($galleryImagePaths as $displayOrder => $imagePath) {
                TourImage::create([
                    'tour_id'       => $tour->id,
                    'image'         => $imagePath,
                    'display_order' => $displayOrder,
                ]);
            }
        });

        return redirect()
            ->route('admin.tours.index')
            ->with('success', 'Passeio criado com sucesso.');
    }
}