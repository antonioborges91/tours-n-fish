<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>
</svg><?php /**PATH C:\wamp64\www\tours-n-fish\storage\framework\views/2eab8f02cebf0af4dd5d4a664f83bbf8.blade.php ENDPATH**/ ?>