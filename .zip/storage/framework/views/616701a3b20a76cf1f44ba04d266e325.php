<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['tour']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['tour']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $translation = $tour->translation();
    $option = $tour->firstOption();

    $duration = null;

    if ($option?->duration_minutes) {

        $hours = intdiv($option->duration_minutes, 60);
        $minutes = $option->duration_minutes % 60;

        if ($minutes === 0) {
            $duration = "{$hours} h";
        } else {
            $duration = "{$hours} h {$minutes} min";
        }
    }
?>

<article class="tour-card">

    <div class="tour-card-image">

        <?php if($tour->cover_image): ?>

            <img
                src="<?php echo e(asset('storage/' . $tour->cover_image)); ?>"
                alt="<?php echo e($translation?->name); ?>">

        <?php endif; ?>

    </div>

    <div class="tour-card-content">

        <h3>
            <?php echo e($translation?->name); ?>

        </h3>

        <div class="tour-card-meta">

            <span>

                <svg
                    class="meta-icon"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    stroke-width="2">

                    <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        d="M12 6v6l4 2"/>

                    <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        d="M12 22a10 10 0 100-20 10 10 0 000 20z"/>

                </svg>

                <?php echo e($duration); ?>


            </span>

            <span>

                <svg
                    class="meta-icon"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    stroke-width="2">

                    <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/>

                    <circle
                        cx="9"
                        cy="7"
                        r="4"/>

                    <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        d="M23 21v-2a4 4 0 00-3-3.87"/>

                    <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        d="M16 3.13a4 4 0 010 7.75"/>

                </svg>

                <?php echo e(__('home.card.people', ['count' => $tour->max_capacity])); ?>


            </span>

        </div>

        <div class="tour-card-footer">

            <div class="tour-card-price">

                <small>
                    <?php echo e(__('home.card.from')); ?>

                </small>

                <strong>
                    €<?php echo e(number_format($option?->price ?? 0, 0, ',', '.')); ?>

                </strong>

                <span>
                    <?php echo e(__('home.card.per_trip')); ?>

                </span>

            </div>

            <a
                href="<?php echo e(route('tours.show', $tour)); ?>"
                class="link-arrow">
                <?php echo e(__('home.card.learn_more')); ?>

            </a>

        </div>

    </div>

</article><?php /**PATH C:\wamp64\www\tours-n-fish\resources\views/components/tour-card.blade.php ENDPATH**/ ?>