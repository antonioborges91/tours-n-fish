<header class="absolute inset-x-0 top-0 z-50 hidden lg:block">

    <div class="container-custom">

        <div class="grid grid-cols-[auto_1fr_auto] items-center py-8 px-10">

            
            <a href="<?php echo e(route('home')); ?>" class="shrink-0" aria-label="Tours N Fish">

                <?php if (isset($component)) { $__componentOriginal987d96ec78ed1cf75b349e2e5981978f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal987d96ec78ed1cf75b349e2e5981978f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.logo','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal987d96ec78ed1cf75b349e2e5981978f)): ?>
<?php $attributes = $__attributesOriginal987d96ec78ed1cf75b349e2e5981978f; ?>
<?php unset($__attributesOriginal987d96ec78ed1cf75b349e2e5981978f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal987d96ec78ed1cf75b349e2e5981978f)): ?>
<?php $component = $__componentOriginal987d96ec78ed1cf75b349e2e5981978f; ?>
<?php unset($__componentOriginal987d96ec78ed1cf75b349e2e5981978f); ?>
<?php endif; ?>

            </a>

            
            <nav class="flex justify-center" aria-label="Navegação Principal">

                <ul class="flex items-center gap-10">

                    <li>
                        <a href="<?php echo e(route('home')); ?>"
                           class="<?php echo e(request()->routeIs('home') ? 'nav-link nav-link-active' : 'nav-link'); ?>">
                            <?php echo e(__('navigation.home')); ?>

                        </a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('tours')); ?>"
                           class="<?php echo e(request()->routeIs('tours') ? 'nav-link nav-link-active' : 'nav-link'); ?>">
                            <?php echo e(__('navigation.tours')); ?>

                        </a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('about')); ?>"
                           class="<?php echo e(request()->routeIs('about') ? 'nav-link nav-link-active' : 'nav-link'); ?>">
                            <?php echo e(__('navigation.about')); ?>

                        </a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('gallery')); ?>"
                           class="<?php echo e(request()->routeIs('gallery') ? 'nav-link nav-link-active' : 'nav-link'); ?>">
                            <?php echo e(__('navigation.gallery')); ?>

                        </a>
                    </li>

                    <li>
                        <a
                            href="<?php echo e(route('contact')); ?>"
                            class="<?php echo e(request()->routeIs('contact') ? 'nav-link nav-link-active' : 'nav-link'); ?>">

                            <?php echo e(__('navigation.contact')); ?>


                        </a>
                    </li>

                </ul>

            </nav>

            
            <div class="ml-auto flex items-center gap-5 shrink-0">

                <?php echo $__env->make('components.navbar.language-switch', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <a href="#" class="btn-primary">
                    <?php echo e(__('navigation.book_now')); ?>

                </a>

            </div>

        </div>

    </div>

</header><?php /**PATH C:\wamp64\www\tours-n-fish\resources\views/components/navbar/desktop.blade.php ENDPATH**/ ?>