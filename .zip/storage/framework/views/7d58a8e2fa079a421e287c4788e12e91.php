<?php $__env->startSection('content'); ?>

<div class="admin-page admin-reservation-show-page">

    <div class="admin-page-header">
        <div>
            <h1>Reserva #<?php echo e($reservation->reservation_number); ?></h1>
            <p>Detalhes da reserva e informação do cliente.</p>
        </div>

        <a
            href="<?php echo e(route('admin.reservations.index')); ?>"
            class="admin-btn-secondary"
        >
            ← Voltar às reservas
        </a>
    </div>

    <?php
        $statusLabels = [
            'pending_payment' => 'A aguardar pagamento',
            'payment_submitted' => 'Comprovativo enviado',
            'confirmed' => 'Confirmada',
            'rejected' => 'Rejeitada',
            'cancelled' => 'Cancelada',
            'expired' => 'Expirada',
        ];

        $statusLabel = $statusLabels[$reservation->status]
            ?? $reservation->status;
    ?>

    <div class="admin-reservation-grid">

        
        <div class="admin-card">

            <div class="admin-card-header">
                <div>
                    <span class="admin-card-label">Reserva</span>
                    <h2>
                        <?php echo e($reservation->tour?->translation()?->name ?? '—'); ?>

                    </h2>
                </div>

                <span class="admin-status admin-status-<?php echo e($reservation->status); ?>">
                    <?php echo e($statusLabel); ?>

                </span>
            </div>

            <div class="admin-detail-list">

                <div class="admin-detail-row">
                    <span>Passeio</span>
                    <strong>
                        <?php echo e($reservation->tour?->translation()?->name ?? '—'); ?>

                    </strong>
                </div>

                <div class="admin-detail-row">
                    <span>Opção</span>
                    <strong>
                        <?php echo e($reservation->option?->translation()?->name ?? '—'); ?>

                    </strong>
                </div>

                <div class="admin-detail-row">
                    <span>Data</span>
                    <strong>
                        <?php echo e($reservation->booking_date?->format('d/m/Y') ?? '—'); ?>

                    </strong>
                </div>

                <div class="admin-detail-row">
                    <span>Horário</span>
                    <strong>
                        <?php echo e(\Carbon\Carbon::parse($reservation->start_at)->format('H:i')); ?>

                        -
                        <?php echo e(\Carbon\Carbon::parse($reservation->end_at)->format('H:i')); ?>

                    </strong>
                </div>

                <div class="admin-detail-row">
                    <span>Pessoas</span>
                    <strong><?php echo e($reservation->participants); ?></strong>
                </div>

            </div>

        </div>

        
        <div class="admin-card">

            <div class="admin-card-header">
                <div>
                    <span class="admin-card-label">Cliente</span>
                    <h2>Dados do cliente</h2>
                </div>
            </div>

            <div class="admin-detail-list">

                <div class="admin-detail-row">
                    <span>Nome</span>
                    <strong><?php echo e($reservation->customer_name); ?></strong>
                </div>

                <div class="admin-detail-row">
                    <span>Email</span>
                    <strong><?php echo e($reservation->customer_email); ?></strong>
                </div>

                <div class="admin-detail-row">
                    <span>Telefone</span>
                    <strong><?php echo e($reservation->customer_phone); ?></strong>
                </div>

                <div class="admin-detail-row admin-detail-row-column">
                    <span>Observações</span>
                    <p>
                        <?php echo e($reservation->customer_message ?: 'Sem observações.'); ?>

                    </p>
                </div>

            </div>

        </div>

        
        <div class="admin-card">

            <div class="admin-card-header">
                <div>
                    <span class="admin-card-label">Pagamento</span>
                    <h2>Valores e comprovativo</h2>
                </div>
            </div>

            <div class="admin-detail-list">

                <div class="admin-detail-row">
                    <span>Total da reserva</span>
                    <strong>
                        €<?php echo e(number_format($reservation->total_amount, 2, ',', '.')); ?>

                    </strong>
                </div>

                <div class="admin-detail-row">
                    <span>
                        Sinal (<?php echo e(number_format($reservation->deposit_percentage, 0)); ?>%)
                    </span>
                    <strong>
                        €<?php echo e(number_format($reservation->deposit_amount, 2, ',', '.')); ?>

                    </strong>
                </div>

                <div class="admin-detail-row">
                    <span>Prazo de pagamento</span>
                    <strong>
                        <?php echo e($reservation->payment_deadline_at
                            ? $reservation->payment_deadline_at->format('d/m/Y H:i')
                            : '—'); ?>

                    </strong>
                </div>

            </div>

            <div class="admin-payment-proof">

                <div>
                    <span class="admin-card-label">Comprovativo</span>

                    <?php if($reservation->payment_proof): ?>
                        <strong class="admin-payment-proof-status is-sent">
                            Recebido
                        </strong>

                        <?php if($reservation->payment_submitted_at): ?>
                            <p>
                                Enviado em
                                <?php echo e($reservation->payment_submitted_at->format('d/m/Y H:i')); ?>

                            </p>
                        <?php endif; ?>
                    <?php else: ?>
                        <strong class="admin-payment-proof-status is-missing">
                            Ainda não enviado
                        </strong>
                    <?php endif; ?>
                </div>

                <?php if($reservation->payment_proof): ?>
                    <a
                        href="<?php echo e(route('admin.reservations.payment-proof', $reservation)); ?>"
                        target="_blank"
                        rel="noopener"
                        class="admin-payment-proof-button"
                    >
                        Ver comprovativo
                    </a>
                <?php endif; ?>

            </div>

        </div>

        
        <div class="admin-card">

            <div class="admin-card-header">
                <div>
                    <span class="admin-card-label">Estado</span>
                    <h2>Histórico da reserva</h2>
                </div>
            </div>

            <div class="admin-detail-list">

                <div class="admin-detail-row">
                    <span>Estado atual</span>
                    <strong><?php echo e($statusLabel); ?></strong>
                </div>

                <div class="admin-detail-row">
                    <span>Pedido criado em</span>
                    <strong>
                        <?php echo e($reservation->created_at?->format('d/m/Y H:i') ?? '—'); ?>

                    </strong>
                </div>

                <?php if($reservation->payment_submitted_at): ?>
                    <div class="admin-detail-row">
                        <span>Comprovativo enviado em</span>
                        <strong>
                            <?php echo e($reservation->payment_submitted_at->format('d/m/Y H:i')); ?>

                        </strong>
                    </div>
                <?php endif; ?>

                <?php if($reservation->confirmed_at): ?>
                    <div class="admin-detail-row">
                        <span>Confirmada em</span>
                        <strong>
                            <?php echo e($reservation->confirmed_at->format('d/m/Y H:i')); ?>

                        </strong>
                    </div>
                <?php endif; ?>

                <?php if($reservation->cancelled_at): ?>
                    <div class="admin-detail-row">
                        <span>Cancelada em</span>
                        <strong>
                            <?php echo e($reservation->cancelled_at->format('d/m/Y H:i')); ?>

                        </strong>
                    </div>
                <?php endif; ?>

            </div>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\tours-n-fish\resources\views/admin/reservations/show.blade.php ENDPATH**/ ?>