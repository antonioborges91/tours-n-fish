<section class="hero">

    <div class="hero-card">

        <div
            class="hero-background"
            style="background-image:url('<?php echo e(asset('images/hero/hero.webp')); ?>')">
        </div>

        <div class="hero-gradient"></div>

        <div class="hero-content">

            <h1 class="hero-title">
                <?php echo e(__('home.hero_title_1')); ?><br>
                <span><?php echo e(__('home.hero_title_2')); ?></span>
            </h1>

            <p class="hero-text">
                <?php echo e(__('home.hero_text')); ?>

            </p>

            <div class="hero-actions">

                <a href="#" class="btn-secondary">
                    <?php echo e(__('home.explore')); ?>


                    <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lucide-chevron-right'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'btn-icon w-4 h-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                </a>

            </div>

        </div>

    </div>

    <?php echo $__env->make('pages.home.components.hero-features', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</section><?php /**PATH C:\wamp64\www\tours-n-fish\resources\views/pages/home/sections/hero.blade.php ENDPATH**/ ?>