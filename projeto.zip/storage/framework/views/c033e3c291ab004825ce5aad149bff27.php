<?php
    $translation = $tour->translation();
?>

<section class="tour-show-hero">

    <div class="tour-show-hero-card">

        <div
            class="tour-show-hero-background"
            style="background-image:url('<?php echo e(asset('storage/' . $tour->cover_image)); ?>')">
        </div>

        <div class="tour-show-hero-gradient"></div>

        <div class="tour-show-hero-content">

            <h1 class="tour-show-hero-title">

                <?php echo e($translation->name); ?>


            </h1>

            <p class="tour-show-hero-text">

                <?php echo e($translation->short_description); ?>


            </p>

        </div>

    </div>

</section><?php /**PATH C:\wamp64\www\tours-n-fish\resources\views/pages/tours/sections/show-hero.blade.php ENDPATH**/ ?>