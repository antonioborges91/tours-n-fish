<svg class="footer-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d="m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7"/>
  <rect x="2" y="4" width="20" height="16" rx="2"/>
</svg><?php /**PATH C:\wamp64\www\tours-n-fish\storage\framework\views/6d1213c1f4d82a9306bdeb0c8ba9e969.blade.php ENDPATH**/ ?>