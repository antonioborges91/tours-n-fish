<?php if($tour->images->count()): ?>

<section class="tour-gallery section">

    <div class="container-custom">

        <div class="section-heading">

            <span class="section-badge">

                Galeria

            </span>

            <h2 class="section-title">

                Descubra o passeio em imagens

            </h2>

        </div>

        <div class="tour-gallery-grid">

            <div class="tour-gallery-main">

                <img
                    id="tourMainImage"
                    src="<?php echo e(asset('storage/'.$tour->images->first()->image)); ?>"
                    alt="<?php echo e($tour->translation()->name); ?>"
                >

            </div>

            <div class="tour-gallery-thumbs">

                <?php $__currentLoopData = $tour->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div
                        class="tour-gallery-thumb"
                        data-image="<?php echo e(asset('storage/'.$image->image)); ?>"
                    >

                        <img
                            src="<?php echo e(asset('storage/'.$image->image)); ?>"
                            alt="<?php echo e($tour->translation()->name); ?>"
                        >

                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        </div>

    </div>

</section>

<?php endif; ?><?php /**PATH C:\wamp64\www\tours-n-fish\resources\views/pages/tours/sections/gallery.blade.php ENDPATH**/ ?>