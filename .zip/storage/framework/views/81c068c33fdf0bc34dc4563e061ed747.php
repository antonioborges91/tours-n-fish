<img
    src="<?php echo e(asset('images/logo/logo.png')); ?>"
    alt="Tours N Fish"
    <?php echo e($attributes->merge([
        'class' => 'logo'
    ])); ?>><?php /**PATH C:\wamp64\www\tours-n-fish\resources\views/components/logo.blade.php ENDPATH**/ ?>