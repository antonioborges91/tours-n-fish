<?php

    $sections = [];
    $current = null;

    $lines = preg_split('/\r\n|\r|\n/', $tour->translation()->important_information ?? '');

    foreach ($lines as $line) {

        $line = trim($line);

        if ($line === '') {
            continue;
        }

        // Novo título
        if (str_ends_with($line, ':')) {

            if ($current) {
                $sections[] = $current;
            }

            $current = [
                'title' => rtrim($line, ':'),
                'items' => [],
            ];

            continue;
        }

        if (!$current) {
            continue;
        }

        $current['items'][] = ltrim($line, "-• ");
    }

    if ($current) {
        $sections[] = $current;
    }

?>

<?php if(count($sections)): ?>

<section class="tour-information section-last">

    <div class="container-custom">

        <div class="section-heading">

            <span class="section-badge">

                Informações

            </span>

            <h2 class="section-title">

                Tudo o que precisa de saber

            </h2>

        </div>

        <div class="tour-information-grid">

            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <article class="tour-information-card">

                    <h3>

                        <?php echo e($section['title']); ?>


                    </h3>

                    <ul>

                        <?php $__currentLoopData = $section['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <li>

                                <?php echo e($item); ?>


                            </li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>

                </article>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>

</section>

<?php endif; ?><?php /**PATH C:\wamp64\www\tours-n-fish\resources\views/pages/tours/sections/information.blade.php ENDPATH**/ ?>