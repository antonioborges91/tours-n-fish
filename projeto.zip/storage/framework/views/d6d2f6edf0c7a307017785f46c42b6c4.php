<section class="about-story">

    <div class="container-custom">

        <div class="section-heading">

            <span class="section-subtitle">
                <?php echo e(__('about.story.subtitle')); ?>

            </span>

            <h2 class="section-title">
                <?php echo e(__('about.story.title')); ?>

            </h2>

        </div>

        <div class="about-story-grid">

            <div>

                <p>
                    <?php echo e(__('about.story.paragraph_1')); ?>

                </p>

                <p>
                    <?php echo e(__('about.story.paragraph_2')); ?>

                </p>

            </div>

            <div>

                <img
                    src="<?php echo e(asset('images/about/story.webp')); ?>"
                    alt="Tours N Fish">

            </div>

        </div>

    </div>

</section><?php /**PATH C:\wamp64\www\tours-n-fish\resources\views/pages/about/sections/story.blade.php ENDPATH**/ ?>