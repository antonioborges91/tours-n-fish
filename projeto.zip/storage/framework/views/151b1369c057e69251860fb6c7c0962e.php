<?php $__env->startSection('content'); ?>

<div class="flex items-center justify-between mb-8">

    <div>

        <h1 class="text-3xl font-bold">
            Passeios
        </h1>

        <p class="mt-1 text-gray-500">
            Gerir os passeios do Tours N Fish.
        </p>

    </div>

    <a
        href="<?php echo e(route('admin.tours.create')); ?>"
        class="admin-btn-primary">

        + Novo Passeio

    </a>

</div>

<?php if(session('success')): ?>

    <div class="mb-6 rounded-lg border border-green-300 bg-green-50 p-4 text-green-700">

        <?php echo e(session('success')); ?>


    </div>

<?php endif; ?>

<div class="overflow-hidden rounded-lg bg-white shadow">

    <table class="w-full">

        <thead class="bg-gray-100">

            <tr>

                <th class="p-4 text-left">
                    Capa
                </th>

                <th class="p-4 text-left">
                    Nome
                </th>

                <th class="p-4 text-left">
                    Preço
                </th>

                <th class="p-4 text-left">
                    Duração
                </th>

                <th class="p-4 text-center">
                    Disponível
                </th>

                <th class="p-4 text-center">
                    Home
                </th>

                <th class="p-4 text-right">
                    Ações
                </th>

            </tr>

        </thead>

        <tbody>

        <?php $__empty_1 = true; $__currentLoopData = $tours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

    <?php
        $isFirst = $loop->first;
        $isLast = $loop->last;
    ?>

            <?php

                $translation = $tour->translations
                    ->firstWhere('locale', 'pt');

                $option = $tour->options
                    ->sortBy('display_order')
                    ->first();

                $formattedDuration = '—';

                if ($option) {

                    $minutes = (int) $option->duration_minutes;

                    if ($minutes < 60) {

                        $formattedDuration = $minutes . ' min';

                    } else {

                        $hours = intdiv($minutes, 60);
                        $remainingMinutes = $minutes % 60;

                        $formattedDuration = $hours . ' h';

                        if ($remainingMinutes > 0) {
                            $formattedDuration .= ' ' . $remainingMinutes . ' min';
                        }

                    }

                }

            ?>

            <tr class="border-t">

                <td class="p-4">

                    <img
                        src="<?php echo e(asset('storage/' . $tour->cover_image)); ?>"
                        alt="<?php echo e($translation?->name); ?>"
                        class="h-24 w-24 rounded-lg object-cover">

                </td>

                <td class="p-4 font-medium">

                    <div class="max-w-xs truncate">

                        <?php echo e($translation?->name ?? 'Sem nome'); ?>


                    </div>

                </td>

                <td class="p-4">

                    <?php if($option): ?>

                        € <?php echo e(number_format($option->price, 2, ',', '.')); ?>


                    <?php else: ?>

                        —

                    <?php endif; ?>

                </td>

                <td class="p-4">

                    <?php echo e($formattedDuration); ?>


                </td>

                <td class="p-4 text-center">

                    <?php if($tour->available): ?>

                        <span class="rounded-full bg-green-100 px-3 py-1 text-sm text-green-700">

                            Disponível

                        </span>

                    <?php else: ?>

                        <span class="rounded-full bg-red-100 px-3 py-1 text-sm text-red-700">

                            Indisponível

                        </span>

                    <?php endif; ?>

                </td>

                <td class="p-4 text-center text-xl">

                    <?php if($tour->featured_home): ?>

                        ⭐

                    <?php else: ?>

                        <span class="text-gray-400">
                            ★
                        </span>

                    <?php endif; ?>

                </td>

                <td class="p-4">

                    <div class="flex justify-end items-center gap-2">

    <?php if (! ($isFirst)): ?>

        <form
            action="<?php echo e(route('admin.tours.move', $tour)); ?>"
            method="POST">

            <?php echo csrf_field(); ?>

            <input
                type="hidden"
                name="direction"
                value="up">

            <button
                type="submit"
                class="admin-btn-secondary">

                ↑

            </button>

        </form>

    <?php endif; ?>

    <?php if (! ($isLast)): ?>

        <form
            action="<?php echo e(route('admin.tours.move', $tour)); ?>"
            method="POST">

            <?php echo csrf_field(); ?>

            <input
                type="hidden"
                name="direction"
                value="down">

            <button
                type="submit"
                class="admin-btn-secondary">

                ↓

            </button>

        </form>

    <?php endif; ?>

    <a
        href="<?php echo e(route('admin.tours.edit', $tour)); ?>"
        class="admin-btn-secondary">

        Editar

    </a>

    <form
        action="<?php echo e(route('admin.tours.destroy', $tour)); ?>"
        method="POST"
        onsubmit="return confirm('Tem a certeza que pretende eliminar este passeio?');">

        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>

        <button
            type="submit"
            class="admin-btn-danger">

            Eliminar

        </button>

    </form>

</div>

                </td>

            </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <tr>

                <td
                    colspan="7"
                    class="py-12 text-center text-gray-500">

                    Ainda não existem passeios.

                </td>

            </tr>

        <?php endif; ?>

        </tbody>

    </table>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\tours-n-fish\resources\views/admin/tours/index.blade.php ENDPATH**/ ?>