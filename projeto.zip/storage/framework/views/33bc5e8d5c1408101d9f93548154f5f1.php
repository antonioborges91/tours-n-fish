

<?php $__env->startSection('content'); ?>

<div class="flex items-end justify-between">

    <div>

        <h1 class="text-3xl font-bold">
            Galeria
        </h1>

        <p class="mt-1 text-gray-500">
            Gerir as fotografias da galeria.
        </p>

    </div>

    <a
        href="<?php echo e(route('admin.gallery.create')); ?>"
        class="admin-btn-primary">

        + Adicionar Fotografia

    </a>

</div>

<?php if(session('success')): ?>

    <div class="mb-6 mt-6 rounded-lg border border-green-300 bg-green-50 p-4 text-green-700">

        <?php echo e(session('success')); ?>


    </div>

<?php endif; ?>

<div class="mt-8 overflow-hidden rounded-xl border border-gray-200 bg-white">

    <table class="w-full">

        <thead class="bg-gray-100">

            <tr>

                <th class="p-4 text-left">
                    Fotografia
                </th>

                <th class="p-4 text-center">
                    Estado
                </th>

                <th class="p-4 text-center">
                    Ordem
                </th>

                <th class="p-4 text-right">
                    Ações
                </th>

            </tr>

        </thead>

        <tbody>

        <?php $__empty_1 = true; $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <?php
                $isFirst = $loop->first;
                $isLast = $loop->last;
            ?>

            <tr class="border-t">

                <td class="p-4">

                    <img
                        src="<?php echo e(asset('storage/' . $photo->image)); ?>"
                        alt="Fotografia"
                        class="h-24 w-24 rounded-lg object-cover">

                </td>

                <td class="p-4 text-center">

                    <?php if($photo->is_active): ?>

                        <span class="rounded-full bg-green-100 px-3 py-1 text-sm text-green-700">

                            Ativa

                        </span>

                    <?php else: ?>

                        <span class="rounded-full bg-red-100 px-3 py-1 text-sm text-red-700">

                            Inativa

                        </span>

                    <?php endif; ?>

                </td>

                <td class="p-4 text-center">

                    <?php echo e($photo->sort_order); ?>


                </td>

                <td class="p-4">

                    <div class="flex items-center justify-end gap-2">

                        <?php if (! ($isFirst)): ?>

                            <form
                                action="<?php echo e(route('admin.gallery.move', $photo)); ?>"
                                method="POST">

                                <?php echo csrf_field(); ?>

                                <input
                                    type="hidden"
                                    name="direction"
                                    value="up">

                                <button
                                    type="submit"
                                    class="admin-btn-secondary">

                                    ↑

                                </button>

                            </form>

                        <?php endif; ?>

                        <?php if (! ($isLast)): ?>

                            <form
                                action="<?php echo e(route('admin.gallery.move', $photo)); ?>"
                                method="POST">

                                <?php echo csrf_field(); ?>

                                <input
                                    type="hidden"
                                    name="direction"
                                    value="down">

                                <button
                                    type="submit"
                                    class="admin-btn-secondary">

                                    ↓

                                </button>

                            </form>

                        <?php endif; ?>

                        <a
                            href="<?php echo e(route('admin.gallery.edit', $photo)); ?>"
                            class="admin-btn-secondary">

                            Editar

                        </a>

                        <form
                            action="<?php echo e(route('admin.gallery.destroy', $photo)); ?>"
                            method="POST"
                            onsubmit="return confirm('Tem a certeza que pretende eliminar esta fotografia?');">

                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>

                            <button
                                type="submit"
                                class="admin-btn-danger">

                                Eliminar

                            </button>

                        </form>

                    </div>

                </td>

            </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <tr>

                <td
                    colspan="4"
                    class="py-12 text-center text-gray-500">

                    Ainda não existem fotografias.

                </td>

            </tr>

        <?php endif; ?>

        </tbody>

    </table>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\tours-n-fish\resources\views/admin/gallery/index.blade.php ENDPATH**/ ?>