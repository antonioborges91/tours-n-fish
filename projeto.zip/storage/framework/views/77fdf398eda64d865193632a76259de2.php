<section class="tours-hero">

    <div class="tours-hero-card">

        <div
            class="tours-hero-background"
            style="background-image:url('<?php echo e(asset('images/tours/header.webp')); ?>')">
        </div>

        <div class="tours-hero-gradient"></div>

        <div class="tours-hero-content">

            <h1 class="tours-hero-title">

                <?php echo e(__('tours.hero.title')); ?><br>

                <span><?php echo e(__('tours.hero.highlight')); ?></span>

            </h1>

            <p class="tours-hero-text">

                <?php echo e(__('tours.hero.text')); ?>


            </p>

        </div>

    </div>

</section><?php /**PATH C:\wamp64\www\tours-n-fish\resources\views/pages/tours/sections/hero.blade.php ENDPATH**/ ?>