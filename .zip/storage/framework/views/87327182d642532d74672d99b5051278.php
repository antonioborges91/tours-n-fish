<div class="language-switch">

    <?php if(app()->getLocale() === 'pt'): ?>

        <span class="active">PT</span>

        <span class="divider"></span>

        <a href="<?php echo e(route('language.switch', 'en')); ?>">EN</a>

    <?php else: ?>

        <a href="<?php echo e(route('language.switch', 'pt')); ?>">PT</a>

        <span class="divider"></span>

        <span class="active">EN</span>

    <?php endif; ?>

</div><?php /**PATH C:\wamp64\www\tours-n-fish\resources\views/components/navbar/language-switch.blade.php ENDPATH**/ ?>