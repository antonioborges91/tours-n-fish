<section class="gallery-hero">

    <div class="gallery-hero-card">

        <div
            class="gallery-hero-background"
            style="background-image:url('<?php echo e(asset('images/gallery/hero.webp')); ?>')">
        </div>

        <div class="gallery-hero-gradient"></div>

        <div class="gallery-hero-content">

            <h1 class="gallery-hero-title">

                <?php echo e(__('gallery.hero.title')); ?><br>

                <span><?php echo e(__('gallery.hero.highlight')); ?></span>

            </h1>

            <p class="gallery-hero-text">

                <?php echo e(__('gallery.hero.text')); ?>


            </p>

        </div>

    </div>

</section><?php /**PATH C:\wamp64\www\tours-n-fish\resources\views/pages/gallery/sections/hero.blade.php ENDPATH**/ ?>