

<?php $__env->startSection('title', $tour->translation()->name); ?>

<?php $__env->startSection('content'); ?>

<div class="tour-show">

    <?php echo $__env->make('pages.tours.sections.show-hero', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('pages.tours.sections.description', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('pages.tours.sections.options', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('pages.tours.sections.gallery', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('pages.tours.sections.information', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</div>
<?php $__env->startPush('scripts'); ?>

<script>

document.addEventListener('DOMContentLoaded', () => {

    const mainImage = document.getElementById('tourMainImage');

    const thumbs = document.querySelectorAll('.tour-gallery-thumb');

    thumbs.forEach((thumb) => {

        thumb.addEventListener('click', () => {

            mainImage.src = thumb.dataset.image;

            thumbs.forEach(item => item.classList.remove('active'));

            thumb.classList.add('active');

        });

    });

    if (thumbs.length) {

        thumbs[0].classList.add('active');

    }

});

</script>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\tours-n-fish\resources\views/pages/tours/show.blade.php ENDPATH**/ ?>