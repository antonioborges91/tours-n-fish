<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d="M12 6v16"/>
  <path d="m19 13 2-1a9 9 0 0 1-18 0l2 1"/>
  <path d="M9 11h6"/>
  <circle cx="12" cy="4" r="2"/>
</svg>