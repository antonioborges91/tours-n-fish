<section class="about-hero">

    <div class="about-hero-card">

        <div
            class="about-hero-background"
            style="background-image:url('<?php echo e(asset('images/about/hero.webp')); ?>')">
        </div>

        <div class="about-hero-gradient"></div>

        <div class="about-hero-content">

            <h1 class="about-hero-title">

                <?php echo e(__('about.hero.title')); ?><br>

                <span><?php echo e(__('about.hero.highlight')); ?></span>

            </h1>

            <p class="about-hero-text">

                <?php echo e(__('about.hero.text')); ?>


            </p>

        </div>

    </div>

</section><?php /**PATH C:\wamp64\www\tours-n-fish\resources\views/pages/about/sections/hero.blade.php ENDPATH**/ ?>