<section class="contact-map">

    <div class="container-custom">

        <div class="section-heading">

            <span class="section-badge">

                <?php echo e(__('contact.map.badge')); ?>


            </span>

            <h2 class="section-title">

                <?php echo e(__('contact.map.title')); ?>


            </h2>

        </div>

        <div class="contact-map-wrapper">

            <iframe
                src="https://www.google.com/maps?q=Marina+de+Ponta+Delgada,+São+Miguel,+Açores&output=embed"
                loading="lazy"
                allowfullscreen
                referrerpolicy="no-referrer-when-downgrade">
            </iframe>

        </div>

    </div>

</section><?php /**PATH C:\wamp64\www\tours-n-fish\resources\views/pages/contact/sections/map.blade.php ENDPATH**/ ?>