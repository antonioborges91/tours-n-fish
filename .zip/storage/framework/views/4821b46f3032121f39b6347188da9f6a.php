

<?php $__env->startSection('content'); ?>

<div class="flex items-end justify-between">

    <div>

        <h1 class="text-3xl font-bold">
            Períodos Bloqueados
        </h1>

        <p class="mt-1 text-gray-500">
            Gerir os dias e períodos em que não estão disponíveis passeios.
        </p>

    </div>

    <a
        href="<?php echo e(route('admin.blocked-periods.create')); ?>"
        class="admin-btn-primary">

        + Adicionar Período

    </a>

</div>

<?php if(session('success')): ?>

    <div class="mb-6 mt-6 rounded-lg border border-green-300 bg-green-50 p-4 text-green-700">

        <?php echo e(session('success')); ?>


    </div>

<?php endif; ?>

<div class="mt-8 overflow-hidden rounded-xl border border-gray-200 bg-white">

    <table class="w-full">

        <thead class="bg-gray-100">

            <tr>

                <th class="p-4 text-left">
                    Início
                </th>

                <th class="p-4 text-left">
                    Fim
                </th>

                <th class="p-4 text-left">
                    Motivo
                </th>

                <th class="p-4 text-right">
                    Ações
                </th>

            </tr>

        </thead>

        <tbody>

        <?php $__empty_1 = true; $__currentLoopData = $blockedPeriods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blockedPeriod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <tr class="border-t">

                <td class="p-4">

                    <div class="font-medium text-gray-900">

                        <?php echo e($blockedPeriod->start_at->format('d/m/Y')); ?>


                    </div>

                    <div class="text-sm text-gray-500">

                        <?php echo e($blockedPeriod->start_at->format('H:i')); ?>


                    </div>

                </td>

                <td class="p-4">

                    <div class="font-medium text-gray-900">

                        <?php echo e($blockedPeriod->end_at->format('d/m/Y')); ?>


                    </div>

                    <div class="text-sm text-gray-500">

                        <?php echo e($blockedPeriod->end_at->format('H:i')); ?>


                    </div>

                </td>

                <td class="p-4">

                    <?php if($blockedPeriod->reason): ?>

                        <?php echo e($blockedPeriod->reason); ?>


                    <?php else: ?>

                        <span class="text-gray-400">
                            Sem motivo indicado
                        </span>

                    <?php endif; ?>

                </td>

                <td class="p-4">

                    <div class="flex items-center justify-end gap-2">

                        <a
                            href="<?php echo e(route('admin.blocked-periods.edit', $blockedPeriod)); ?>"
                            class="admin-btn-secondary">

                            Editar

                        </a>

                        <form
                            action="<?php echo e(route('admin.blocked-periods.destroy', $blockedPeriod)); ?>"
                            method="POST"
                            onsubmit="return confirm('Tem a certeza que pretende eliminar este período bloqueado?');">

                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>

                            <button
                                type="submit"
                                class="admin-btn-danger">

                                Eliminar

                            </button>

                        </form>

                    </div>

                </td>

            </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <tr>

                <td
                    colspan="4"
                    class="py-12 text-center text-gray-500">

                    Ainda não existem períodos bloqueados.

                </td>

            </tr>

        <?php endif; ?>

        </tbody>

    </table>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\tours-n-fish\resources\views/admin/blocked-periods/index.blade.php ENDPATH**/ ?>