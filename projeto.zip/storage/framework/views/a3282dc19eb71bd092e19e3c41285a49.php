<section class="contact-hero">

    <div class="contact-hero-card">

        <div
            class="contact-hero-background"
            style="background-image:url('<?php echo e(asset('images/contact/hero.webp')); ?>')">
        </div>

        <div class="contact-hero-gradient"></div>

        <div class="contact-hero-content">

            <h1 class="contact-hero-title">

                <?php echo e(__('contact.hero.title')); ?><br>

                <span><?php echo e(__('contact.hero.highlight')); ?></span>

            </h1>

            <p class="contact-hero-text">

                <?php echo e(__('contact.hero.text')); ?>


            </p>

        </div>

    </div>

</section><?php /**PATH C:\wamp64\www\tours-n-fish\resources\views/pages/contact/sections/hero.blade.php ENDPATH**/ ?>