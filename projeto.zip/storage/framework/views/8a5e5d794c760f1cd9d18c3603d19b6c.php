<div>

    <label>

        Fotografia

    </label>

    <input
        type="file"
        name="image">

</div>

<?php if(isset($gallery)): ?>

    <p>

        <img
            src="<?php echo e(asset('storage/'.$gallery->image)); ?>"
            width="220"
            alt="">

    </p>

<?php endif; ?>

<div>

    <label>

        <input
            type="checkbox"
            name="is_active"
            value="1"
            <?php if(old('is_active',$gallery->is_active ?? true)): echo 'checked'; endif; ?>>

        Ativa

    </label>

</div>

<button
    type="submit"
    class="admin-button">

    Guardar

</button><?php /**PATH C:\wamp64\www\tours-n-fish\resources\views/admin/gallery/partials/form.blade.php ENDPATH**/ ?>