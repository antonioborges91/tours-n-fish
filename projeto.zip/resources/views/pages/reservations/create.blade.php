@extends('layouts.app')

@section('title', 'Reservar ' . $tour->translation()->name)

@section('content')

<section class="reservation-page">

    <div class="container-custom">

        <div class="section-heading">

            <span class="section-badge">
                Reserva
            </span>

            <h1 class="section-title">
                {{ $option->translation()->name }}
            </h1>

            <p>
                {{ $tour->translation()->name }}
            </p>

        </div>


        <div class="reservation-layout">

            {{-- Resumo do passeio --}}

            <div class="reservation-card">

                <div class="reservation-card-header">

                    <h2>
                        Dados do passeio
                    </h2>

                </div>

                <div class="reservation-details">

                    <div class="reservation-detail">

                        <span class="reservation-label">
                            Opção
                        </span>

                        <strong>
                            {{ $option->translation()->name }}
                        </strong>

                    </div>


                    <div class="reservation-detail">

                        <span class="reservation-label">
                            Horário
                        </span>

                        <strong>

                            {{ substr($schedule->start_time, 0, 5) }}

                            —

                            {{ substr($schedule->end_time, 0, 5) }}

                        </strong>

                    </div>


                    <div class="reservation-detail">

                        <span class="reservation-label">
                            Duração
                        </span>

                        <strong>
                            {{ $option->duration_minutes }} minutos
                        </strong>

                    </div>


                    <div class="reservation-detail">

                        <span class="reservation-label">
                            Capacidade
                        </span>

                        <strong>
                            Até {{ $tour->max_capacity }} pessoas
                        </strong>

                    </div>

                </div>


                <div class="reservation-price-box">

                    <div>

                        <span>
                            Preço do passeio
                        </span>

                        <strong>
                            €{{ number_format($option->price, 2, ',', '.') }}
                        </strong>

                    </div>


                    <div>

                        <span>
                            Sinal de 10%
                        </span>

                        <strong>
                            €{{ number_format($option->price * 0.10, 2, ',', '.') }}
                        </strong>

                    </div>

                </div>


                <div class="reservation-notice">

                    <strong>
                        Como funciona a reserva
                    </strong>

                    <p>
                        Após enviar o pedido, a reserva ficará pendente.
                        Receberá um email com as instruções para pagamento
                        do sinal de 10%. A reserva só será confirmada após
                        a confirmação desse pagamento.
                    </p>

                </div>

            </div>


            {{-- Formulário --}}

            <div class="reservation-card">

                <div class="reservation-card-header">

                    <h2>
                        Os seus dados
                    </h2>

                    <p>
                        Preencha os dados para solicitar a reserva.
                    </p>

                </div>


                <form
                    method="POST"
                    action="{{ route('reservations.store') }}"
                    class="reservation-form">

                    @csrf


                    {{-- Identificação da reserva --}}

                    <input
                        type="hidden"
                        name="tour_option_id"
                        value="{{ $option->id }}">

                    <input
                        type="hidden"
                        name="tour_option_schedule_id"
                        value="{{ $schedule->id }}">


                    {{-- Data --}}

                    <div class="reservation-field">

                        <label>
                            Data do passeio
                        </label>

                        <input
                            type="hidden"
                            id="booking_date"
                            name="booking_date"
                            value="{{ old('booking_date') }}"
                            required>

                        <div
                            id="reservation-calendar"
                            class="reservation-calendar"
                            data-available-dates='@json($availableDates)'
                            data-unavailable-dates='@json($unavailableDates)'
                            data-selected-date="{{ old('booking_date') }}"
                        ></div>

                        <p
                            id="selected-date-label"
                            class="reservation-selected-date"
                        ></p>

                        @error('booking_date')

                            <p class="reservation-error">
                                {{ $message }}
                            </p>

                        @enderror

                    </div>


                    {{-- Número de pessoas --}}

                    <div class="reservation-field">

                        <label for="participants">
                            Número de pessoas
                        </label>

                        <input
                            type="number"
                            id="participants"
                            name="participants"
                            min="1"
                            max="{{ $tour->max_capacity }}"
                            value="{{ old('participants', 1) }}"
                            required>

                        <p class="reservation-help">
                            Máximo de {{ $tour->max_capacity }} pessoas.
                            O preço apresentado é pelo passeio, não por pessoa.
                        </p>

                        @error('participants')

                            <p class="reservation-error">
                                {{ $message }}
                            </p>

                        @enderror

                    </div>


                    {{-- Nome --}}

                    <div class="reservation-field">

                        <label for="customer_name">
                            Nome
                        </label>

                        <input
                            type="text"
                            id="customer_name"
                            name="customer_name"
                            value="{{ old('customer_name') }}"
                            autocomplete="name"
                            required>

                        @error('customer_name')

                            <p class="reservation-error">
                                {{ $message }}
                            </p>

                        @enderror

                    </div>


                    {{-- Email --}}

                    <div class="reservation-field">

                        <label for="customer_email">
                            Email
                        </label>

                        <input
                            type="email"
                            id="customer_email"
                            name="customer_email"
                            value="{{ old('customer_email') }}"
                            autocomplete="email"
                            required>

                        @error('customer_email')

                            <p class="reservation-error">
                                {{ $message }}
                            </p>

                        @enderror

                    </div>


                    {{-- Telefone --}}

                    <div class="reservation-field">

                        <label for="customer_phone">
                            Telefone
                        </label>

                        <input
                            type="text"
                            id="customer_phone"
                            name="customer_phone"
                            value="{{ old('customer_phone') }}"
                            autocomplete="tel"
                            required>

                        @error('customer_phone')

                            <p class="reservation-error">
                                {{ $message }}
                            </p>

                        @enderror

                    </div>


                    {{-- Observações --}}

                    <div class="reservation-field">

                        <label for="customer_message">
                            Observações
                        </label>

                        <textarea
                            id="customer_message"
                            name="customer_message"
                            rows="5"
                            placeholder="Alguma informação que considere importante?">{{ old('customer_message') }}</textarea>

                        @error('customer_message')

                            <p class="reservation-error">
                                {{ $message }}
                            </p>

                        @enderror

                    </div>


                    {{-- Resumo do pagamento --}}

                    <div class="reservation-payment">

                        <div>

                            <span>
                                Total do passeio
                            </span>

                            <strong>
                                €{{ number_format($option->price, 2, ',', '.') }}
                            </strong>

                        </div>


                        <div>

                            <span>
                                Sinal a pagar
                            </span>

                            <strong>
                                €{{ number_format($option->price * 0.10, 2, ',', '.') }}
                            </strong>

                        </div>

                    </div>


                    <button
                        type="submit"
                        class="btn btn-primary reservation-submit">

                        Enviar pedido de reserva

                    </button>


                    <p class="reservation-form-note">

                        O envio deste formulário não confirma imediatamente
                        a reserva. O pedido ficará sujeito à disponibilidade
                        e confirmação do pagamento do sinal.

                    </p>

                </form>

            </div>

        </div>

    </div>

</section>


@push('styles')

<style>

.reservation-page {
    padding: 70px 0;
}

.reservation-layout {
    display: grid;
    grid-template-columns: minmax(0, 0.9fr) minmax(0, 1.1fr);
    gap: 30px;
    margin-top: 45px;
    align-items: start;
}

.reservation-card {
    background: #ffffff;
    border: 1px solid #e5e7eb;
    border-radius: 18px;
    padding: 30px;
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.05);
}

.reservation-card-header {
    margin-bottom: 25px;
}

.reservation-card-header h2 {
    margin: 0;
    font-size: 1.5rem;
    font-weight: 700;
}

.reservation-card-header p {
    margin-top: 6px;
    color: #6b7280;
}

.reservation-details {
    display: grid;
    gap: 18px;
}

.reservation-detail {
    display: flex;
    justify-content: space-between;
    gap: 20px;
    padding-bottom: 15px;
    border-bottom: 1px solid #edf0f2;
}

.reservation-label {
    color: #6b7280;
}

.reservation-detail strong {
    text-align: right;
}

.reservation-price-box {
    margin-top: 25px;
    padding: 20px;
    border-radius: 14px;
    background: #f7f9fb;
    display: grid;
    gap: 15px;
}

.reservation-price-box > div,
.reservation-payment > div {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
}

.reservation-price-box span,
.reservation-payment span {
    color: #6b7280;
}

.reservation-price-box strong {
    color: #075b94;
    font-size: 1.25rem;
}

.reservation-notice {
    margin-top: 25px;
    padding: 18px;
    border-left: 4px solid #f5b400;
    background: #fff9e6;
    border-radius: 8px;
}

.reservation-notice strong {
    display: block;
    margin-bottom: 7px;
}

.reservation-notice p {
    margin: 0;
    line-height: 1.6;
    color: #4b5563;
}

.reservation-form {
    display: grid;
    gap: 20px;
}

.reservation-field {
    display: grid;
    gap: 7px;
}

.reservation-field label {
    font-weight: 600;
}

.reservation-field input,
.reservation-field textarea {
    width: 100%;
    box-sizing: border-box;
    border: 1px solid #d1d5db;
    border-radius: 9px;
    padding: 12px 14px;
    font: inherit;
    background: #ffffff;
    transition: border-color 0.2s, box-shadow 0.2s;
}

.reservation-field input:focus,
.reservation-field textarea:focus {
    outline: none;
    border-color: #075b94;
    box-shadow: 0 0 0 3px rgba(7, 91, 148, 0.10);
}

.reservation-field textarea {
    resize: vertical;
}

.reservation-help {
    margin: 0;
    font-size: 0.9rem;
    color: #6b7280;
}

.reservation-error {
    margin: 0;
    color: #dc2626;
    font-size: 0.9rem;
}

.reservation-payment {
    padding: 20px;
    border-radius: 14px;
    background: #f7f9fb;
    display: grid;
    gap: 14px;
}

.reservation-payment strong {
    color: #075b94;
    font-size: 1.2rem;
}

.reservation-submit {
    width: 100%;
    margin-top: 5px;
}

.reservation-form-note {
    margin: 0;
    text-align: center;
    color: #6b7280;
    font-size: 0.9rem;
    line-height: 1.5;
}

@media (max-width: 900px) {

    .reservation-layout {
        grid-template-columns: 1fr;
    }

}

@media (max-width: 600px) {

    .reservation-page {
        padding: 45px 0;
    }

    .reservation-card {
        padding: 22px;
    }

    .reservation-detail {
        display: grid;
        gap: 5px;
    }

    .reservation-detail strong {
        text-align: left;
    }

}

.reservation-calendar {
    border: 1px solid #e5e7eb;
    border-radius: 14px;
    padding: 18px;
    background: #ffffff;
}

.reservation-calendar-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    margin-bottom: 18px;
}

.reservation-calendar-header strong {
    font-size: 1.05rem;
}

.reservation-calendar-nav {
    width: 38px;
    height: 38px;
    border: 1px solid #d1d5db;
    border-radius: 8px;
    background: #ffffff;
    cursor: pointer;
    font-size: 1.4rem;
    line-height: 1;
}

.reservation-calendar-nav:hover {
    border-color: #075b94;
}

.reservation-calendar-weekdays,
.reservation-calendar-grid {
    display: grid;
    grid-template-columns: repeat(7, 1fr);
    gap: 6px;
}

.reservation-calendar-weekdays {
    margin-bottom: 6px;
}

.reservation-calendar-weekdays span {
    text-align: center;
    font-size: 0.8rem;
    font-weight: 600;
    color: #6b7280;
    padding: 6px 0;
}

.reservation-calendar-day {
    min-height: 42px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    background: #ffffff;
    cursor: pointer;
    font: inherit;
}

.reservation-calendar-day.is-available:hover {
    border-color: #075b94;
    background: #f0f7fb;
}

.reservation-calendar-day.is-selected {
    background: #075b94;
    color: #ffffff;
    border-color: #075b94;
    font-weight: 700;
}

.reservation-calendar-day.is-unavailable {
    background: #f3f4f6;
    color: #9ca3af;
    text-decoration: line-through;
    cursor: not-allowed;
}

.reservation-calendar-day:disabled {
    opacity: 1;
}

.reservation-calendar-empty {
    min-height: 42px;
}

.reservation-calendar-legend {
    display: flex;
    flex-wrap: wrap;
    gap: 18px;
    margin-top: 18px;
    padding-top: 15px;
    border-top: 1px solid #edf0f2;
    font-size: 0.85rem;
    color: #6b7280;
}

.reservation-calendar-legend span {
    display: inline-flex;
    align-items: center;
    gap: 7px;
}

.legend-dot {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    display: inline-block;
}

.legend-dot.available {
    background: #075b94;
}

.legend-dot.unavailable {
    background: #d1d5db;
}

.reservation-selected-date {
    margin: 8px 0 0;
    font-weight: 600;
    color: #075b94;
}

</style>

@push('scripts')

<script>
document.addEventListener('DOMContentLoaded', () => {

    const calendar = document.getElementById('reservation-calendar');

    if (!calendar) {
        return;
    }

    const bookingDateInput = document.getElementById('booking_date');
    const selectedDateLabel = document.getElementById('selected-date-label');

    const availableDates = JSON.parse(
        calendar.dataset.availableDates || '[]'
    );

    const unavailableDates = JSON.parse(
        calendar.dataset.unavailableDates || '[]'
    );

    let selectedDate = calendar.dataset.selectedDate || '';

    let currentMonth = selectedDate
        ? new Date(selectedDate + 'T00:00:00')
        : new Date();

    currentMonth.setDate(1);


    const formatDate = (year, month, day) => {

        return [
            year,
            String(month + 1).padStart(2, '0'),
            String(day).padStart(2, '0')
        ].join('-');

    };


    const formatDateForDisplay = (dateString) => {

        if (!dateString) {
            return '';
        }

        const [year, month, day] = dateString.split('-');

        return `${day}/${month}/${year}`;
    };


    const isAvailable = (dateString) => {

        return availableDates.includes(dateString);

    };


    const renderCalendar = () => {

        const year = currentMonth.getFullYear();
        const month = currentMonth.getMonth();

        const firstDay = new Date(year, month, 1).getDay();

        const daysInMonth = new Date(
            year,
            month + 1,
            0
        ).getDate();


        const portugueseMonth = new Intl.DateTimeFormat(
            'pt-PT',
            {
                month: 'long',
                year: 'numeric'
            }
        ).format(currentMonth);


        let html = '';

        html += `
            <div class="reservation-calendar-header">

                <button
                    type="button"
                    class="reservation-calendar-nav"
                    data-calendar-prev
                    aria-label="Mês anterior"
                >
                    ‹
                </button>

                <strong>
                    ${portugueseMonth.charAt(0).toUpperCase() + portugueseMonth.slice(1)}
                </strong>

                <button
                    type="button"
                    class="reservation-calendar-nav"
                    data-calendar-next
                    aria-label="Mês seguinte"
                >
                    ›
                </button>

            </div>

            <div class="reservation-calendar-weekdays">
                <span>Seg</span>
                <span>Ter</span>
                <span>Qua</span>
                <span>Qui</span>
                <span>Sex</span>
                <span>Sáb</span>
                <span>Dom</span>
            </div>

            <div class="reservation-calendar-grid">
        `;


        let mondayBasedFirstDay = firstDay === 0
            ? 6
            : firstDay - 1;


        for (let i = 0; i < mondayBasedFirstDay; i++) {

            html += `
                <span class="reservation-calendar-empty"></span>
            `;

        }


        for (let day = 1; day <= daysInMonth; day++) {

            const dateString = formatDate(
                year,
                month,
                day
            );

            const available = isAvailable(dateString);

            const unavailable = unavailableDates.includes(
                dateString
            );

            const selected = selectedDate === dateString;


            let classes = [
                'reservation-calendar-day'
            ];


            if (available) {
                classes.push('is-available');
            }

            if (unavailable) {
                classes.push('is-unavailable');
            }

            if (selected) {
                classes.push('is-selected');
            }


            html += `
                <button
                    type="button"
                    class="${classes.join(' ')}"
                    data-date="${dateString}"
                    ${available ? '' : 'disabled'}
                >
                    ${day}
                </button>
            `;

        }


        html += `
            </div>

            <div class="reservation-calendar-legend">

                <span>
                    <i class="legend-dot available"></i>
                    Disponível
                </span>

                <span>
                    <i class="legend-dot unavailable"></i>
                    Indisponível
                </span>

            </div>
        `;


        calendar.innerHTML = html;


        calendar
            .querySelector('[data-calendar-prev]')
            .addEventListener('click', () => {

                currentMonth.setMonth(
                    currentMonth.getMonth() - 1
                );

                renderCalendar();

            });


        calendar
            .querySelector('[data-calendar-next]')
            .addEventListener('click', () => {

                currentMonth.setMonth(
                    currentMonth.getMonth() + 1
                );

                renderCalendar();

            });


        calendar
            .querySelectorAll('[data-date]')
            .forEach(button => {

                button.addEventListener('click', () => {

                    const date = button.dataset.date;

                    if (!isAvailable(date)) {
                        return;
                    }

                    selectedDate = date;

                    bookingDateInput.value = date;

                    selectedDateLabel.textContent =
                        `Data selecionada: ${formatDateForDisplay(date)}`;

                    renderCalendar();

                });

            });


        if (selectedDate) {

            selectedDateLabel.textContent =
                `Data selecionada: ${formatDateForDisplay(selectedDate)}`;

        } else {

            selectedDateLabel.textContent =
                'Escolha uma data disponível.';

        }

    };


    renderCalendar();

});
</script>


@endpush