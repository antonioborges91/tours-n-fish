<svg class="btn-icon w-4 h-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d="m9 18 6-6-6-6"/>
</svg><?php /**PATH C:\wamp64\www\tours-n-fish\storage\framework\views/af11850e0ac597b8b5533da40c363f2b.blade.php ENDPATH**/ ?>