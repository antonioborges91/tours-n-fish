<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tour_images', function (Blueprint $table) {
            $table->id();

            $table->foreignId('tour_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->string('image');

            $table->unsignedInteger('display_order')->default(0);

            $table->timestamps();

            $table->unique(['tour_id', 'image']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tour_images');
    }
};