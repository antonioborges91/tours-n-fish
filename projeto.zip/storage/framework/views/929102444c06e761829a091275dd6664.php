<section class="tour-options">

    <div class="container-custom">

        <div class="section-heading">

            <span class="section-badge">

                <?php echo e(__('tours.options.badge')); ?>


            </span>

            <h2 class="section-title">

                <?php echo e(__('tours.options.title')); ?>


            </h2>

        </div>

        <div class="tour-options-list">

            <?php $__currentLoopData = $tour->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php

                    $translation = $option->translation();

                    $duration = $option->duration_minutes;

                    if($duration >= 60){

                        $hours = intdiv($duration,60);

                        $minutes = $duration % 60;

                        $durationText = $minutes
                            ? "{$hours} h {$minutes} min"
                            : "{$hours} h";

                    }else{

                        $durationText = "{$duration} min";

                    }

                ?>

                <article class="tour-option">

                    <div class="tour-option-main">

                        <h3>

                            <?php echo e($translation->name); ?>


                        </h3>

                        <div class="tour-option-details">

                            <span>

                                <svg class="meta-icon" xmlns="http://www.w3.org/2000/svg"
                                    width="18" height="18"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    stroke="currentColor"
                                    stroke-width="2"
                                    stroke-linecap="round"
                                    stroke-linejoin="round">

                                    <circle cx="12" cy="12" r="10"/>

                                    <polyline points="12 6 12 12 16 14"/>

                                </svg>

                                <?php echo e($durationText); ?>


                            </span>

                            <span>

                                <svg class="meta-icon" xmlns="http://www.w3.org/2000/svg"
                                    width="18"
                                    height="18"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    stroke="currentColor"
                                    stroke-width="2"
                                    stroke-linecap="round"
                                    stroke-linejoin="round">

                                    <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>

                                    <circle cx="8.5" cy="7" r="4"/>

                                    <path d="M20 8v6"/>

                                    <path d="M23 11h-6"/>

                                </svg>

                                <?php echo e(__('tours.options.up_to', ['count' => $tour->max_capacity])); ?>


                            </span>

                        </div>

                        <?php if($option->schedules->count()): ?>

                            <div class="tour-option-schedules">

                                <p class="tour-option-schedules-title">

                                    <?php echo e(__('tours.options.available_schedules')); ?>


                                </p>

                                <div class="tour-option-schedule-list">

                                    <?php $__currentLoopData = $option->schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <label class="tour-option-schedule">

                                            <input
                                                type="radio"
                                                name="schedule_<?php echo e($option->id); ?>"
                                                value="<?php echo e($schedule->id); ?>"
                                                <?php if($loop->first): echo 'checked'; endif; ?>
                                            >

                                            <span class="tour-option-schedule-card">

                                                <?php echo e(substr($schedule->start_time,0,5)); ?>


                                                —

                                                <?php echo e(substr($schedule->end_time,0,5)); ?>


                                            </span>

                                        </label>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>

                            </div>

                        <?php endif; ?>

                    </div>

                    <div class="tour-option-book">

                        <span class="tour-option-from">

                            <?php echo e(__('tours.options.available_schedules')); ?>


                        </span>

                        <div class="tour-option-price">

                            €<?php echo e(number_format($option->price,0,",",".")); ?>


                        </div>

                        <span class="tour-option-per">

                            <?php echo e(__('tours.options.per_tour')); ?>


                        </span>

                        <a href="#" class="btn btn-primary">

                            <?php echo e(__('tours.options.book')); ?>


                        </a>

                    </div>

                </article>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>

</section><?php /**PATH C:\wamp64\www\tours-n-fish\resources\views/pages/tours/sections/options.blade.php ENDPATH**/ ?>