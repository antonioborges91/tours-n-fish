<?php $__env->startSection('content'); ?>

<div class="admin-page admin-reservations-page">

    <div class="admin-page-header">
        <div>
            <h1>Reservas</h1>
            <p>Gerir as reservas dos passeios.</p>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="admin-alert admin-alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="admin-reservations-table-card">

        <div class="admin-reservations-table-wrap">
            <table class="admin-reservations-table">

                <thead>
                    <tr>
                        <th>Reserva</th>
                        <th>Data</th>
                        <th>Passeio</th>
                        <th>Horário</th>
                        <th>Cliente</th>
                        <th class="is-center">Pessoas</th>
                        <th class="is-right">Valor</th>
                        <th class="is-center">Estado</th>
                        <th class="is-right">Ações</th>
                    </tr>
                </thead>

                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <?php
                        $tourTranslation = $reservation->tour?->translation();
                        $optionTranslation = $reservation->option?->translation();

                        $statusLabels = [
                            'pending_payment' => 'A aguardar pagamento',
                            'payment_submitted' => 'Comprovativo enviado',
                            'confirmed' => 'Confirmada',
                            'rejected' => 'Rejeitada',
                            'cancelled' => 'Cancelada',
                            'expired' => 'Expirada',
                        ];

                        $statusLabel = $statusLabels[$reservation->status]
                            ?? $reservation->status;
                    ?>

                    <tr>

                        <td>
                            <strong class="admin-reservation-number">
                                #<?php echo e($reservation->reservation_number); ?>

                            </strong>
                        </td>

                        <td>
                            <strong>
                                <?php echo e($reservation->booking_date?->format('d/m/Y') ?? '—'); ?>

                            </strong>
                        </td>

                        <td>
                            <div class="admin-table-primary">
                                <?php echo e($tourTranslation?->name ?? 'Passeio'); ?>

                            </div>

                            <?php if($optionTranslation?->name): ?>
                                <div class="admin-table-secondary">
                                    <?php echo e($optionTranslation->name); ?>

                                </div>
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php echo e(\Carbon\Carbon::parse($reservation->start_at)->format('H:i')); ?>

                            -
                            <?php echo e(\Carbon\Carbon::parse($reservation->end_at)->format('H:i')); ?>

                        </td>

                        <td>
                            <div class="admin-table-primary">
                                <?php echo e($reservation->customer_name); ?>

                            </div>

                            <div class="admin-table-secondary">
                                <?php echo e($reservation->customer_email); ?>

                            </div>
                        </td>

                        <td class="is-center">
                            <?php echo e($reservation->participants); ?>

                        </td>

                        <td class="is-right">
                            <strong>
                                € <?php echo e(number_format($reservation->total_amount, 2, ',', '.')); ?>

                            </strong>
                        </td>

                        <td class="is-center">
                            <span class="admin-status admin-status-<?php echo e($reservation->status); ?>">
                                <?php echo e($statusLabel); ?>

                            </span>
                        </td>

                        <td class="is-right">
                            <a
                                href="<?php echo e(route('admin.reservations.show', $reservation)); ?>"
                                class="admin-reservation-action"
                            >
                                Ver
                            </a>
                        </td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>
                        <td colspan="9" class="admin-reservations-empty">
                            Ainda não existem reservas.
                        </td>
                    </tr>

                <?php endif; ?>
                </tbody>

            </table>
        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\tours-n-fish\resources\views/admin/reservations/index.blade.php ENDPATH**/ ?>