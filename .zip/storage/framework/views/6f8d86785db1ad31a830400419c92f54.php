<section class="about-preview">

    <div class="about-preview-image">

        <img
            src="<?php echo e(asset('images/about/about-preview.webp')); ?>"
            alt="Tours N Fish">

    </div>

    <div class="about-preview-content">

        <span class="section-subtitle">
            <?php echo e(__('home.about_badge')); ?>

        </span>

        <h2 class="section-title about-title">
            <?php echo e(__('home.about_title')); ?>

        </h2>

        <p class="about-text">
            <?php echo e(__('home.about_text')); ?>

        </p>

        <a
            href="<?php echo e(route('about')); ?>"
            class="link-arrow">

            <?php echo e(__('home.about_link')); ?> →

        </a>

    </div>

</section><?php /**PATH C:\wamp64\www\tours-n-fish\resources\views/pages/home/sections/about-preview.blade.php ENDPATH**/ ?>