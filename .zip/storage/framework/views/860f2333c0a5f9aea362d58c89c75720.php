<?php $__env->startSection('content'); ?>

<div class="admin-dashboard">

    

    <div class="admin-page-header">

        <div>
            <h1 class="admin-page-title">
                Dashboard
            </h1>

            <p class="admin-page-description">
                Visão geral da atividade e das reservas.
            </p>
        </div>

    </div>


    

    <?php if($paymentSubmittedCount > 0): ?>

        <a
            href="<?php echo e(route('admin.reservations.index')); ?>"
            class="admin-dashboard-alert admin-dashboard-alert-payment"
        >

            <div class="admin-dashboard-alert-icon">
                !
            </div>

            <div class="admin-dashboard-alert-content">

                <strong>
                    <?php echo e($paymentSubmittedCount); ?>

                    <?php echo e($paymentSubmittedCount === 1
                        ? 'reserva tem um comprovativo'
                        : 'reservas têm comprovativo'); ?>

                    para verificar
                </strong>

                <span>
                    Existem pagamentos submetidos pelos clientes que aguardam confirmação.
                </span>

            </div>

            <span class="admin-dashboard-alert-action">
                Ver reservas →
            </span>

        </a>

    <?php endif; ?>


    

    <section class="admin-dashboard-stats">

        <a
            href="<?php echo e(route('admin.tours.index')); ?>"
            class="admin-dashboard-stat"
        >

            <span class="admin-dashboard-stat-label">
                Passeios
            </span>

            <strong class="admin-dashboard-stat-value">
                <?php echo e($totalTours); ?>

            </strong>

            <span class="admin-dashboard-stat-link">
                Gerir passeios →
            </span>

        </a>


        <a
            href="<?php echo e(route('admin.reservations.index')); ?>"
            class="admin-dashboard-stat"
        >

            <span class="admin-dashboard-stat-label">
                Reservas
            </span>

            <strong class="admin-dashboard-stat-value">
                <?php echo e($totalReservations); ?>

            </strong>

            <span class="admin-dashboard-stat-link">
                Ver reservas →
            </span>

        </a>


        <a
            href="<?php echo e(route('admin.gallery.index')); ?>"
            class="admin-dashboard-stat"
        >

            <span class="admin-dashboard-stat-label">
                Galeria
            </span>

            <strong class="admin-dashboard-stat-value">
                <?php echo e($totalGalleryItems); ?>

            </strong>

            <span class="admin-dashboard-stat-link">
                Gerir galeria →
            </span>

        </a>


        <a
            href="<?php echo e(route('admin.blocked-periods.index')); ?>"
            class="admin-dashboard-stat"
        >

            <span class="admin-dashboard-stat-label">
                Bloqueios ativos
            </span>

            <strong class="admin-dashboard-stat-value">
                <?php echo e($totalBlockedPeriods); ?>

            </strong>

            <span class="admin-dashboard-stat-link">
                Gerir bloqueios →
            </span>

        </a>

    </section>


    

    <section class="admin-dashboard-section">

        <div class="admin-dashboard-section-header">

            <div>
                <span class="admin-dashboard-section-label">
                    Reservas
                </span>

                <h2>
                    Estado atual
                </h2>
            </div>

            <a
                href="<?php echo e(route('admin.reservations.index')); ?>"
                class="admin-dashboard-section-link"
            >
                Ver todas
            </a>

        </div>


        <div class="admin-dashboard-status-grid">

            <a
                href="<?php echo e(route('admin.reservations.index')); ?>"
                class="admin-dashboard-status-card status-payment"
            >
                <span>
                    A aguardar pagamento
                </span>

                <strong>
                    <?php echo e($pendingPaymentCount); ?>

                </strong>
            </a>


            <a
                href="<?php echo e(route('admin.reservations.index')); ?>"
                class="admin-dashboard-status-card status-submitted"
            >
                <span>
                    Comprovativo enviado
                </span>

                <strong>
                    <?php echo e($paymentSubmittedCount); ?>

                </strong>
            </a>


            <div class="admin-dashboard-status-card status-confirmed">

                <span>
                    Confirmadas
                </span>

                <strong>
                    <?php echo e($confirmedReservationsCount); ?>

                </strong>

            </div>


            <div class="admin-dashboard-status-card status-cancelled">

                <span>
                    Canceladas
                </span>

                <strong>
                    <?php echo e($cancelledReservationsCount); ?>

                </strong>

            </div>


            <div class="admin-dashboard-status-card status-rejected">

                <span>
                    Rejeitadas
                </span>

                <strong>
                    <?php echo e($rejectedReservationsCount); ?>

                </strong>

            </div>


            <div class="admin-dashboard-status-card status-expired">

                <span>
                    Expiradas
                </span>

                <strong>
                    <?php echo e($expiredReservationsCount); ?>

                </strong>

            </div>

        </div>

    </section>


    

    <div class="admin-dashboard-columns">


        

        <section class="admin-dashboard-panel">

            <div class="admin-dashboard-panel-header">

                <div>
                    <span class="admin-dashboard-section-label">
                        Atenção
                    </span>

                    <h2>
                        Reservas a tratar
                    </h2>
                </div>

                <a
                    href="<?php echo e(route('admin.reservations.index')); ?>"
                    class="admin-dashboard-section-link"
                >
                    Ver todas
                </a>

            </div>


            <?php if($attentionReservations->isEmpty()): ?>

                <div class="admin-dashboard-empty">
                    <strong>
                        Tudo tratado.
                    </strong>

                    <span>
                        Não existem reservas pendentes de intervenção.
                    </span>
                </div>

            <?php else: ?>

                <div class="admin-dashboard-reservation-list">

                    <?php $__currentLoopData = $attentionReservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php
                            $tourTranslation = $reservation->tour?->translations
                                ?->firstWhere('locale', app()->getLocale());

                            $optionTranslation = $reservation->option?->translations
                                ?->firstWhere('locale', app()->getLocale());

                            $statusLabels = [
                                'pending_payment' => 'A aguardar pagamento',
                                'payment_submitted' => 'Comprovativo enviado',
                                'confirmed' => 'Confirmada',
                                'rejected' => 'Rejeitada',
                                'cancelled' => 'Cancelada',
                                'expired' => 'Expirada',
                            ];
                        ?>

                        <a
                            href="<?php echo e(route('admin.reservations.show', $reservation)); ?>"
                            class="admin-dashboard-reservation"
                        >

                            <div class="admin-dashboard-reservation-main">

                                <strong>
                                    #<?php echo e($reservation->reservation_number ?? $reservation->id); ?>

                                </strong>

                                <span>
                                    <?php echo e($tourTranslation?->name ?? '—'); ?>

                                </span>

                                <small>
                                    <?php echo e($reservation->customer_name); ?>

                                </small>

                            </div>


                            <div class="admin-dashboard-reservation-meta">

                                <strong>
                                    <?php echo e($reservation->booking_date?->format('d/m/Y') ?? '—'); ?>

                                </strong>

                                <span>
                                    <?php echo e(\Carbon\Carbon::parse($reservation->start_at)->format('H:i')); ?>

                                    -
                                    <?php echo e(\Carbon\Carbon::parse($reservation->end_at)->format('H:i')); ?>

                                </span>

                            </div>


                            <span class="admin-status admin-status-<?php echo e($reservation->status); ?>">
                                <?php echo e($statusLabels[$reservation->status] ?? $reservation->status); ?>

                            </span>

                        </a>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            <?php endif; ?>

        </section>


        

        <section class="admin-dashboard-panel">

            <div class="admin-dashboard-panel-header">

                <div>
                    <span class="admin-dashboard-section-label">
                        Agenda
                    </span>

                    <h2>
                        Próximas reservas
                    </h2>
                </div>

                <a
                    href="<?php echo e(route('admin.reservations.index')); ?>"
                    class="admin-dashboard-section-link"
                >
                    Ver todas
                </a>

            </div>


            <?php if($upcomingReservations->isEmpty()): ?>

                <div class="admin-dashboard-empty">

                    <strong>
                        Não existem próximas reservas.
                    </strong>

                    <span>
                        As novas reservas aparecerão aqui.
                    </span>

                </div>

            <?php else: ?>

                <div class="admin-dashboard-reservation-list">

                    <?php $__currentLoopData = $upcomingReservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php
                            $tourTranslation = $reservation->tour?->translations
                                ?->firstWhere('locale', app()->getLocale());
                        ?>

                        <a
                            href="<?php echo e(route('admin.reservations.show', $reservation)); ?>"
                            class="admin-dashboard-reservation"
                        >

                            <div class="admin-dashboard-reservation-date">

                                <strong>
                                    <?php echo e($reservation->booking_date?->format('d')); ?>

                                </strong>

                                <span>
                                    <?php echo e($reservation->booking_date?->translatedFormat('M')); ?>

                                </span>

                            </div>


                            <div class="admin-dashboard-reservation-main">

                                <strong>
                                    <?php echo e($tourTranslation?->name ?? '—'); ?>

                                </strong>

                                <span>
                                    <?php echo e($reservation->customer_name); ?>

                                </span>

                                <small>
                                    <?php echo e($reservation->participants); ?>

                                    <?php echo e($reservation->participants === 1 ? 'pessoa' : 'pessoas'); ?>

                                    ·
                                    <?php echo e(\Carbon\Carbon::parse($reservation->start_at)->format('H:i')); ?>

                                </small>

                            </div>


                            <span class="admin-dashboard-reservation-arrow">
                                →
                            </span>

                        </a>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            <?php endif; ?>

        </section>

    </div>


    

    <section class="admin-dashboard-panel admin-dashboard-latest">

        <div class="admin-dashboard-panel-header">

            <div>
                <span class="admin-dashboard-section-label">
                    Atividade
                </span>

                <h2>
                    Últimas reservas
                </h2>
            </div>

            <a
                href="<?php echo e(route('admin.reservations.index')); ?>"
                class="admin-dashboard-section-link"
            >
                Ver todas
            </a>

        </div>


        <div class="admin-dashboard-latest-list">

            <?php $__currentLoopData = $latestReservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php
                    $tourTranslation = $reservation->tour?->translations
                        ?->firstWhere('locale', app()->getLocale());

                    $statusLabels = [
                        'pending_payment' => 'A aguardar pagamento',
                        'payment_submitted' => 'Comprovativo enviado',
                        'confirmed' => 'Confirmada',
                        'rejected' => 'Rejeitada',
                        'cancelled' => 'Cancelada',
                        'expired' => 'Expirada',
                    ];
                ?>

                <a
                    href="<?php echo e(route('admin.reservations.show', $reservation)); ?>"
                    class="admin-dashboard-latest-row"
                >

                    <span class="admin-dashboard-latest-number">
                        #<?php echo e($reservation->reservation_number ?? $reservation->id); ?>

                    </span>

                    <span class="admin-dashboard-latest-tour">
                        <?php echo e($tourTranslation?->name ?? '—'); ?>

                    </span>

                    <span class="admin-dashboard-latest-customer">
                        <?php echo e($reservation->customer_name); ?>

                    </span>

                    <span class="admin-dashboard-latest-date">
                        <?php echo e($reservation->created_at?->format('d/m/Y H:i') ?? '—'); ?>

                    </span>

                    <span class="admin-status admin-status-<?php echo e($reservation->status); ?>">
                        <?php echo e($statusLabels[$reservation->status] ?? $reservation->status); ?>

                    </span>

                </a>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </section>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\tours-n-fish\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>