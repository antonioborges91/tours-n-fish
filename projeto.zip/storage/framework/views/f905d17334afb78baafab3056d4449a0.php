

<?php $__env->startSection('title', __('navigation.contact')); ?>

<?php $__env->startSection('content'); ?>

<section class="contact">

    <?php echo $__env->make('pages.contact.sections.hero', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('pages.contact.sections.info', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('pages.contact.sections.map', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\tours-n-fish\resources\views/pages/contact/index.blade.php ENDPATH**/ ?>