

<?php $__env->startSection('title', 'Passeios'); ?>

<?php $__env->startSection('content'); ?>

<section class="tours">

    <?php echo $__env->make('pages.tours.sections.hero', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('pages.tours.sections.tours-grid', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\tours-n-fish\resources\views/pages/tours/index.blade.php ENDPATH**/ ?>