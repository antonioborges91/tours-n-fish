<section class="tour-description">

    <div class="container-custom">

        <span class="section-badge">

            <?php echo e(__('tours.description.badge')); ?>


        </span>

        <div class="tour-description-text">

            <?php echo nl2br(e($tour->translation()->full_description)); ?>


        </div>

    </div>

</section><?php /**PATH C:\wamp64\www\tours-n-fish\resources\views/pages/tours/sections/description.blade.php ENDPATH**/ ?>